const express = require('express');
const app = express();
const port = 3000;
const oneLinerJoke = require('one-liner-joke');
const cors = require('cors');

app.use(cors());

app.get('/api/joke', (req, res) => {
    const category = req.query.category;

    if (category) {
        console.log(`Requested category: ${category}`);
        try {
            // Fetch a joke based on the provided category
            const joke = oneLinerJoke.getRandomJokeWithTag(category);

            console.log(`Joke retrieved: ${joke ? joke.body : 'No joke found'}`);

            if (joke) {
                return res.json({ joke: joke.body });
            } else {
                return res.status(404).json({ error: 'No jokes found for the provided category' });
            }
        } catch (error) {
            console.error('Error fetching joke:', error);
            return res.status(500).json({ error: 'Failed to retrieve joke' });
        }
    } else {
        try {
            // Fetch a random joke
            const joke = oneLinerJoke.getRandomJoke().body;
            console.log(`Random joke retrieved: ${joke}`);
            return res.json({ joke: joke });
        } catch (error) {
            console.error('Error fetching joke:', error);
            return res.status(500).json({ error: 'Failed to retrieve joke' });
        }
    }
});

app.listen(port, () => {
    console.log(`Joke API listening at http://localhost:${port}`);
});
